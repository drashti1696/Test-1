<?php
/**
* Plugin Name: Book Library Plugin
* Description: Book Library plugin for wordpress
* Version: 1.0
**/


function james_adds_to_the_head() {
 
    //wp_enqueue_script('jquery');
 
  wp_enqueue_script( 'custom', plugins_url('/js/custom.js', __FILE__), array(), '1.0.0', true );
   wp_localize_script( 'custom', 'my_ajax_object', array( 'ajax_url' => admin_url( 'admin-ajax.php' ) ) );
    wp_enqueue_script( 'jquery', 'https://code.jquery.com/jquery-1.11.3.min.js', array(), '1.0.0', true );
    wp_enqueue_script( 'jquery', 'https://code.jquery.com/mobile/1.4.5/jquery.mobile-1.4.5.min.js', array(), '1.0.0', true );

 
}
 
add_action( 'wp_enqueue_scripts', 'james_adds_to_the_head' );


// plugin activation code
function book_library_activate() { 
    // Trigger our function that registers the custom post type plugin.
    do_basic_things(); 
    book_library_register_taxonomy();
    book_add_custom_box();
    // book_save_postdata();
    show_books_list();
    // Clear the permalinks after the post type has been registered.
    flush_rewrite_rules(); 
}
register_activation_hook( __FILE__, 'book_library_activate' );

add_action("wp_ajax_show_books_list", "show_books_list");
add_action("wp_ajax_nopriv_show_books_list", "show_books_list");

// create shortcode for books
function show_books_list(){
	// echo 'a';
	// print_r($_POST['book']);
	// if($_POST)
	ob_start();
	// print_r($_POST);
	?>

	<div class="container">
		<div class="filter">
			<h2>Book Search</h2>
			<form action="#" method="post" id="book_filter">
				<input type="text" name="book_name">
				<?php
				$authors = get_terms( array(
					'taxonomy' => 'author',
					'hide_empty' => 'false'
				));?>
				<select>
					<option>All Authors</option>
				<?php
				foreach ($authors as $key ) {
					?>
					<option value="<?php echo $key->slug; ?>"><?php echo $key->name; ?></option>
					<?php
				}
				?>
				</select>
				<?php
				$pubs = get_terms( array(
					'taxonomy' => 'publisher',
					'hide_empty' => 'false'
				));?>
				<select>
					<option>All Publishers</option>
				<?php
				foreach ($pubs as $key ) {
					?>
					<option value="<?php echo $key->slug; ?>"><?php echo $key->name; ?></option>
					<?php
				}
				?>
				</select>
				<!-- <select>
					<option>All Ratings</option>
				</select> -->
				<input type="submit" name="submit" value="Search" class="submit_search">
			</form>
		</div>
		<div class="listing">
			<?php
			// echo 'abc' . $_POST['book'];
			$args = array(
				'post_type' => 'book',
				'posts_per_page' => 4,

			);
			if(isset($_POST['book'])){
				$args['s'] = $_POST['book'];
			}
			$loop = new WP_Query($args);
			while ($loop->have_posts()) {
				 $loop->the_post();
			 	?>
			 	<div class="book_single">
			 		<h3 style="display: inline-block;width:30%;"><?php the_title(); ?></h3>
			 		<span style="display: inline-block;width:30%;" class="author"><?php 
			 		//print_r(get_the_terms(get_the_ID(),'author'));
			 		foreach ($variable = get_the_terms(get_the_ID(),'author') as $key) {
			 			echo $key->name.' ';
			 		}
			 		?></span>
			 		<span class="publisher" style="display: inline-block;width:30%;">
			 			<?php
			 			// get_the_terms(get_the_ID(),'publisher');
			 			foreach ($variable = get_the_terms(get_the_ID(),'publisher') as $key) {
			 			echo $key->name.' ';
			 		}
			 			?>
			 		</span>
			 	</div>
			 	<?php
			}

			?>
		</div>
	</div>
	<?php
	$html  = ob_get_contents();
	ob_end_clean();
	return $html;
}
add_shortcode('books_list' , 'show_books_list');


add_action('init', 'do_basic_things');


// register custom post type books 

function do_basic_things(){
		$labels = array( 
 
        'name' => __( 'Books' , 'test' ),
 
        'singular_name' => __( 'book' , 'test' ),
 
        'add_new' => __( 'New book' , 'test' ),
 
        'add_new_item' => __( 'Add New book' , 'test' ),
 
        'edit_item' => __( 'Edit book' , 'test' ),
 
        'new_item' => __( 'New book' , 'test' ),
 
        'view_item' => __( 'View book' , 'test' ),
 
        'search_items' => __( 'Search books' , 'test' ),
 
        'not_found' =>  __( 'No books Found' , 'test' ),
 
        'not_found_in_trash' => __( 'No books found in Trash' , 'test' ),
 
    );
 
    $args = array(
 
        'labels' => $labels,
 
        'has_archive' => true,
 
        'public' => true,
 
        'hierarchical' => false,
 
        'supports' => array(
 
            'title', 
 
            'editor', 
 
            'excerpt', 
 
            'custom-fields', 
 
            'thumbnail',
 
            'page-attributes'
 
        ),
 
        'rewrite'   => array( 'slug' => 'books' ),
 
        'show_in_rest' => true
 
    );
        // register_taxonomy( 'author', array( 'test' ), $args);
        // register_taxonomy( 'publisher', array( 'test_movie' ), $args);

        register_post_type('book' , $args);
}

// create taxonomies for book post type

function book_library_register_taxonomy() {    
      
    // books
    $labels1 = array(
        'name' => __( 'authors' , 'test' ),
        'singular_name' => __( 'Author', 'test' ),
        'search_items' => __( 'Search authors' , 'test' ),
        'all_items' => __( 'All authors' , 'test' ),
        'edit_item' => __( 'Edit author' , 'test' ),
        'update_item' => __( 'Update authors' , 'test' ),
        'add_new_item' => __( 'Add New author' , 'test' ),
        'new_item_name' => __( 'New author Name' , 'test' ),
        'menu_name' => __( 'authors' , 'test' ),
    );
      
    $args1 = array(
        'labels' => $labels1,
        'hierarchical' => true,
        'sort' => true,
        'args' => array( ),
        'rewrite' => array( 'slug' => 'authors' ),
        'show_admin_column' => true,
        'show_in_rest' => true
  
    );

    $labels2 = array(
        'name' => __( 'publishers' , 'test' ),
        'singular_name' => __( 'publisher', 'test' ),
        'search_items' => __( 'Search publishers' , 'test' ),
        'all_items' => __( 'All publishers' , 'test' ),
        'edit_item' => __( 'Edit publisher' , 'test' ),
        'update_item' => __( 'Update publishers' , 'test' ),
        'add_new_item' => __( 'Add New publisher' , 'test' ),
        'new_item_name' => __( 'New publisher Name' , 'test' ),
        'menu_name' => __( 'publishers' , 'test' ),
    );
      
    $args2 = array(
        'labels' => $labels2,
        'hierarchical' => true,
        'sort' => true,
        'args' => array(  ),
        'rewrite' => array( 'slug' => 'publishers' ),
        'show_admin_column' => true,
        'show_in_rest' => true
  
    );
      
    register_taxonomy( 'author', array( 'book' ), $args1);
    register_taxonomy( 'publisher', array( 'book' ), $args2);

      
}
add_action( 'init', 'book_library_register_taxonomy' );


// Custom field meta boxes
function book_add_custom_box() {
    
        add_meta_box(
            'book_price',                 // Unique ID
            'Book Price',      // Box title
            'book_custom_box_html2',  // Content callback, must be of type callable
            'book'                            // Post type
        );
         add_meta_box(
            'book_ratings',                 // Unique ID
            'Book Ratings',      // Box title
            'book_custom_box_html1',  // Content callback, must be of type callable
            'book'                           // Post type
        );
    
}
add_action( 'add_meta_boxes', 'book_add_custom_box' );

function book_custom_box_html1( $post ) {
    ?>
    <label for="book_ratings">Select Rating</label>
    <select name="book_ratings" id="book_ratings" class="postbox">
        <option value="1">1</option>
        <option value="2">2</option>
        <option value="3">3</option>
        <option value="4">4</option>
        <option value="5">5</option>

    </select>
    <?php
}

function book_custom_box_html2( $post ) {
    ?>
    <label for="book_price">Select Rating</label>
    <input type="range" name="book_price" id="book_price" value="200" min="50" max="1000">
    <label for="price-max">Price:</label>
        <input type="range" name="price-max" id="price-max" value="800" min="50" max="1000">
    
    <?php
}


//saving custom fields
function book_save_postdata( $post_id ) {
    if ( array_key_exists( 'book_price', $_POST ) ) {
        update_post_meta(
            $post_id,
            'book_price',
            $_POST['book_price']
        );
    }
    // echo $post_id;
    // print_r($_POST);
     if ( array_key_exists( 'book_ratings', $_POST ) ) {
        update_post_meta(
            $post_id,
            '_book_ratings',
            $_POST['book_ratings']
        );
    }
}
add_action( 'save_post', 'book_save_postdata', 10);
?>