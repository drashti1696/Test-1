jQuery(document).ready(function(){
console.log('dd');
	jQuery('.submit_search').click(function(e){
		e.preventDefault();
		// console.log('f');
		var book = jQuery('input[name=book_name]').val();
		jQuery.ajax({
    type: "post",
    dataType: "json",
    url: my_ajax_object.ajax_url,
    data : {action: "show_books_list", book : book},
    success: function(msg){
        // console.log(msg);
        jQuery(".listing").load(location.href + " .listing");

    }
});
		return true;
	});
});